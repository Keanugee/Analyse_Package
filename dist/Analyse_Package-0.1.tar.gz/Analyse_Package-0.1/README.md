# Analyse_Package

Returns the top n items in an array in descending order

## building this package locally
'python setup.py sdist'

## installing this package from GitHub
'pip install git+'https://github.com/keanugee/Analyse_Package.git'

## updating this package from GitHub
'pip install --upgrade git+'https://github.com/keanugee/Analyse_Package.git'
